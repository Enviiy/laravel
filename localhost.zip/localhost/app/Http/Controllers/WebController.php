<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class WebController extends Controller
{
    public function index()
    {
        $array = DB::table('product')->limit(5)->get();
        return view('home', compact('array'));
    }
    public function catalog()
    {
        $array = DB::table("product")->get();
        return view('catalog', compact('array'));
    }
    public function basket($id)
    {
        $basket = DB::table("product")->where("id_product", '=', $id)->first();
        return view('basket', compact('basket'));
    }
    public function admp()
    {
        return view('admp');
    }
    public function complite()
    {
        return view('complite');
    }
    public function lk()
    {
        return view('lk');
    }
    public function order($id)
    {
        $order = DB::table("product")->where("id_product", '=', $id)->first();
        return view('order', compact('order'));
    }
    public function poisk()
    {
        return view('poisk');
    }
    public function product($id)
    {
        $card = DB::table("product")->where("id_product", '=', $id)->first();
        return view('product', compact('card'));

    }
    public function redact_product()
    {
        return view('redact_product');
    }
    public function reg()
    {
        return view('reg');
    }
    public function sign_in()
    {
        return view('sign_in');
    }
}
