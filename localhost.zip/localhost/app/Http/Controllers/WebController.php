<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class WebController extends Controller
{
    public function home()
    {
        return view('home');
    }
    public function catalog()
    {
        $array = DB::table("product")->get();
        return view('catalog', compact('array'));
    }
    public function basket()
    {
        return view('basket');
    }
    public function admp()
    {
        return view('admp');
    }
    public function complite()
    {
        return view('complite');
    }
    public function lk()
    {
        return view('lk');
    }
    public function order()
    {
        return view('order');
    }
    public function poisk()
    {
        return view('poisk');
    }
    public function product()
    {
        return view('product');

    }
    public function redact_product()
    {
        return view('redact_product');
    }
    public function reg()
    {
        return view('reg');
    }
    public function sign_in()
    {
        return view('sign_in');
    }
}
