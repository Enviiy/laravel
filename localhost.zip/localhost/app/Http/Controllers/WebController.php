<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class WebController extends Controller
{
    public function index()
    {
        return view('home');
    }
    public function catalog()
    {
        $array = DB::table("product")->get();
        return view('catalog', compact('array'));
    }
    public function basket()
    {
        $array = DB::table("product")->get();
        return view('basket', compact('array')) ;
    }
    public function admp()
    {
        return view('admp', compact('array'));
    }
    public function complite()
    {
        $array = DB::table("product")->get();
        return view('complite' );
    }
    public function lk()
    {
        $array = DB::table("product")->get();
        return view('lk');
    }
    public function order()
    {
        $array = DB::table("product")->get();
        return view('order', compact('array'));
    }
    public function poisk()
    {
        return view('poisk');
    }
    public function product()
    {
        $array = DB::table("product")->get();
        return view('product' , compact('array'));

    }
    public function redact_product()
    {
        return view('redact_product');
    }
    public function reg()
    {
        return view('reg');
    }
    public function sign_in()
    {
        return view('sign_in');
    }
}
