<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [App\Http\Controllers\WebController::class, 'index'])->name('index');


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/catalog', [App\Http\Controllers\WebController::class, 'catalog'])->name('catalog');
Route::get('/basket/{id}', [App\Http\Controllers\WebController::class, 'basket'])->name('basket');
Route::get('/admp', [App\Http\Controllers\WebController::class, 'admp'])->name('admp');
Route::get('/lk', [App\Http\Controllers\WebController::class, 'lk'])->name('lk');
Route::get('/order/{id?}', [App\Http\Controllers\WebController::class, 'order'])->name('order');
Route::get('/poisk', [App\Http\Controllers\WebController::class, 'poisk'])->name('poisk');
Route::get('/product/{id?}', [App\Http\Controllers\WebController::class, 'product'])->name('product');
Route::get('/redact_product', [App\Http\Controllers\WebController::class, 'redact_product'])->name('redact_product');
Route::get('/reg', [App\Http\Controllers\WebController::class, 'reg'])->name('reg');
Route::get('/poisk', [App\Http\Controllers\WebController::class, 'poisk'])->name('poisk');
Route::get('/sign_in', [App\Http\Controllers\WebController::class, 'sign_in'])->name('sign_in');
