@extends('layouts.app')

@section('content')
    <div class="o_nas">
        <h1>Заказ успешно оформлен!</h1>
        <a href="{{ url('/') }}" class="btn btn-primary fs-3" style="display: block; justify-self: center; margin-top: 30px;">на главную</a>
    </div>
@endsection
