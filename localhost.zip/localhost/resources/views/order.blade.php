@extends('layouts.app')

@section('content')
    <div class="o_nas">
        <h1>Оформление заказа</h1>
    </div>
    <div class="d-flex justify-content-center">
        <div class="card mb-3 m-5" style="width: 70em;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="public/assets/img/image.png" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title fs-3">Принтер</h5>
                        <p class="card-text fs-5">Крутой принтер</p>
                        <p class="card-text fs-6">2т.</p>
                    </div>
                </div>
            </div>
            <div class="card" style="height: 20px width: 30rem;">
                <div class="card-body">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary">-</button>
                        <button type="button" class="btn btn-primary">1</button>
                        <button type="button" class="btn btn-primary">+</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary">0 рублей</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary">Адресс: Буммашевская ул., 17А, Ижевск</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary">Цена: 2к рублей</button>
                    </div>
                    <a href="{{ route('complite') }}" class="btn btn-primary">Оформить</a>
                    <div class="main">
                        <a href="{{ route('catalog') }}">Продолжить покупки</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
