@extends('layouts.app')

@section('content')
    <div class="o_nas">
        <h1>Оформление заказа</h1>
    </div>
    <div class="d-flex justify-content-center">
        <div class="card mb-3 m-5" style="width: 70em;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="../public/{{$order->image}}" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title fs-1">{{$order->name_product}}</h5>
                        <p class="card-text fs-3">{{$order->description_product}}</p>
                        <p class="card-text fs-4">{{$order->price_product}} рублей</p>
                    </div>
                </div>
            </div>
            <div class="card" style="height: 20px width: 30rem;">
                <div class="card-body">
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <button type="button" class="btn btn-primary">-</button>
                        <button type="button" class="btn btn-primary">1</button>
                        <button type="button" class="btn btn-primary">+</button>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <p>0 рублей</p>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <p >Адресс: Буммашевская ул., 17А, Ижевск</p>
                    </div>
                    <div class="btn-group" role="group" aria-label="Basic example">
                        <p>Цена: {{$order->price_product}} рублей</p>
                    </div>
                    <a href="{{ route('catalog') }}" class="btn btn-primary">купить</a>
                </div>
            </div>
        </div>
    </div>
@endsection
