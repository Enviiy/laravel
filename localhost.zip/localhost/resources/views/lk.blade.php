@extends('layouts.app')

@section('content')
<div class="o_nas">
    <h1>Личный кабинет</h1>
</div>
<div class="container">
    <div class="card" style="width: 20rem; display: block; justify-self: center; margin-top: 50px;">
        <img src="public/assets/img/image.png" class="card-img-top" alt="avatar">
        <div class="card-body">
            <h5 class="card-title"></h5>
            <p class="card-text"></p>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item">Имя: Принтер</li>
            <li class="list-group-item">Фамилия: Принтеров</li>
            <li class="list-group-item">Отчество: Принтерович</li>
            <li class="list-group-item">Login: printer123</li>
            <li class="list-group-item">Email: coolprinter7500@gmail.com</li>
            <a href="{{ route('reg') }}" class="text-bg-danger p-3">Выйти</a>
        </ul>
    </div>
</div>
<div class="o_nas">
    <h1>Заказы</h1>
</div>
<table class="table table-striped" style="margin-bottom: 100px; margin-top: 30px;">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">ФИО</th>
        <th scope="col">название</th>
        <th scope="col">Статус</th>
        <th scope="col">кол-во</th>
        <th scope="col">Время</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <th scope="row">1</th>
        <td>Принтеров Принтер Принтерович</td>
        <td>принтер</td>
        <td>Завершенный</td>
        <td>1 шт.</td>
        <td>14:10:00</td>
    </tr>
    <tr>
        <th scope="row">2</th>
        <td>Принтеров Принтер Принтерович</td>
        <td>принтер</td>
        <td>Подтвержденный</td>
        <td>1 шт.</td>
        <td>18:32:00</td>
    </tr>
    </tbody>
</table>
@endsection
