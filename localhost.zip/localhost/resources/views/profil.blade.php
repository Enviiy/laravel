@extends('layouts.app')

@section('content')
    <div class="container py-4 pt-5 mt-5">
    <div class="row mb-4">
        <div class="card border-0 shadow-sm mb-4">
          <div class="card-header bg-transparent border-0 py-3">
            <h5 class="fw-bold mb-0">Основная информация</h5>
          </div>
          <div class="card-body">
            <div class="row g-3">
              <div class="col-md-6">
                <label class="form-label text-muted">Имя</label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-primary"></i></span>
                  <input type="text" class="form-control border-start-0" value="Артем" readonly>
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label text-muted">Фамилия</label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0"><i class="bi bi-person text-primary"></i></span>
                  <input type="text" class="form-control border-start-0" value="Петрович" readonly>
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label text-muted">Email</label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-primary"></i></span>
                  <input type="email" class="form-control border-start-0" value="temacool@gmail.com" readonly>
                </div>
              </div>
              <div class="col-md-6">
                <label class="form-label text-muted">Телефон</label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0"><i class="bi bi-phone text-primary"></i></span>
                  <input type="tel" class="form-control border-start-0" value="+7 (999) 123-45-67" readonly>
                </div>
              </div>
              <div class="col-12">
                <label class="form-label text-muted">Дата рождения</label>
                <div class="input-group">
                  <span class="input-group-text bg-light border-end-0"><i class="bi bi-calendar text-primary"></i></span>
                  <input type="text" class="form-control border-start-0" value="12.12.2007" readonly>
                </div>
              </div>
            </div>
            <div class="mt-4">
              <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editProfileModal">
                <i class="bi bi-pencil me-2"></i>Редактировать профиль
              </button>
            </div>
          </div>
        </div>

        <div class="card border-0 shadow-sm mb-4">
          <div class="card-header bg-transparent border-0 py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">Адреса доставки</h5>
            <button class="btn btn-sm btn-primary">
              <i class="bi bi-plus"></i> Добавить адрес
            </button>
          </div>
          <div class="card-body">
            <div class="row g-3">
              <div class="col-md-6">
                <div class="border rounded p-3 position-relative">
                  <div class="position-absolute top-0 end-0 m-2">
                  </div>
                  <p class="mb-1 fw-bold">Домашний адрес</p>
                  <p class="text-muted mb-2">г. Москва, ул. Геймерская, д. 15, кв. 42</p>
                  <div class="d-flex gap-2">
                    <button class="btn btn-sm btn-outline-primary">Редактировать</button>
                    <button class="btn btn-sm btn-outline-danger">Удалить</button>
                  </div>
                </div>
              </div>

          <div class="card-header bg-transparent border-0 py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">заказы</h5>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover align-middle">
                <thead class="table-light">
                  <tr>
                    <th>№ заказа</th>
                    <th>Дата</th>
                    <th>Товары</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td><span class="fw-bold">#1</span></td>
                    <td>01.01.2026</td>
                    <td>Ninjutso Sora V2</td>
                    <td>6, 999 ₽</td>
                    <td><span class="badge bg-success p-2">Доставлен</span></td>
                  </tr>
                  <tr>
                    <td><span class="fw-bold">#2</span></td>
                    <td>02.01.2026</td>
                    <td>Epomaker EK68</td>
                    <td>5,999 ₽</td>
                    <td><span class="badge bg-warning text-dark p-2">В пути</span></td>
                  </tr>
                  <tr>
                    <td><span class="fw-bold">#3</span></td>
                    <td>03.01.2026</td>
                    <td>Moondrop Blessing 3</td>
                    <td>32,000 ₽</td>
                    <td><span class="badge bg-info p-2">Обработка</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
      </div>
    </div>
  </div>
  </div>
@endsection
