@extends('layouts.app')

@section('content')
<div class="container d-grid" style="max-width: 700px; width: 100%; margin-top: 100px;">
    <select class="form-select" aria-label="Default select example">
        <option selected>Сортировать по</option>
        <option value="1">Году выпуска</option>
        <option value="2">Названию</option>
        <option value="3">цене</option>
        <option value="4">лазерные принтеры</option>
        <option value="5">струйные принтеры</option>
        <option value="6">термопринтеры</option>
    </select>
</div>
@foreach($array as $a)
    <div class="container d-grid">
        <div class="row m-5 gap-3 ">
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="{{$a ->image_product}}" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title">{{$a ->name_product}} </h5>
                    <p class="card-text">{{$a ->description_product}}</p>
                    <p class="card-text">{{$a ->price_product}}</p>
                    <a href="{{ route('product') }}" class="btn btn-primary fs-6">Подробнее</a>
                    <a href="{{ route('basket') }}" class="btn btn-primary fs-6">В корзину</a>
                    <a href="{{ route('redact_product') }}" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
        </div>
    </div>
@endforeach
</div>
</div>
@endsection
