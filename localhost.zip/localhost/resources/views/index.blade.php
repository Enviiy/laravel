@extends('layouts.app')

@section('content')
    <style>
        .hero-section {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        }
        .navbar {
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
    </style>
  <div class="container-fluid p-0 pt-5">
    <div class="hero-section text-light py-4">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <h1 class="display-5 fw-bold mb-3">Игровая периферия премиум-класса</h1>
            <p class="lead mb-4">Откройте для себя мир высокотехнологичных игровых устройств для максимального погружения и побед</p>
            <a href="{{ route('catalog') }}" class="btn btn-warning btn-lg fw-bold">В каталог <i class="bi bi-arrow-right"></i></a>
          </div>
          <div class="col-lg-6">
            <img src="https://images.unsplash.com/photo-1593305841991-05c297ba4575?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="img-fluid rounded shadow-lg" alt="Игровая периферия">
          </div>
        </div>
      </div>
    </div>

    <div class="container py-5">
      <h2 class="text-center mb-5">Немного о нас</h2>

      <div class="card mb-5 border-0 shadow-sm">
        <div class="row g-0">
          <div class="col-md-4">
            <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80" class="img-fluid rounded-start" alt="Игровая студия">
          </div>
          <div class="col-md-8">
            <div class="card-body p-4">
              <h3 class="card-title mb-3">Periphery - лидер игровой периферии</h3>
              <p class="card-text mb-3">Мы специализируемся на продаже высококачественной игровой периферии уже более 15 лет. Наша команда геймеров тщательно тестирует каждое устройство, чтобы предложить вам только лучшее.</p>
              <p class="card-text mb-3">В нашем ассортименте представлены товары от ведущих мировых брендов: Razer, Logitech, SteelSeries, Corsair, HyperX и многих других.</p>
              <p class="card-text"><small class="text-muted">Работаем с 2008 года, обслужили более 50,000 клиентов</small></p>
            </div>
          </div>
        </div>
      </div>

      <div class="row text-center mb-5">
        <div class="col-md-3 mb-4">
          <div class="p-4 border rounded shadow-sm h-100">
            <i class="bi bi-truck fs-1 text-warning mb-3"></i>
            <h5>Быстрая доставка</h5>
            <p>Доставка по всей России за 1-3 дня</p>
          </div>
        </div>
        <div class="col-md-3 mb-4">
          <div class="p-4 border rounded shadow-sm h-100">
            <i class="bi bi-shield-check fs-1 text-warning mb-3"></i>
            <h5>Гарантия качества</h5>
            <p>Гарантия на все товары от 1 года</p>
          </div>
        </div>
        <div class="col-md-3 mb-4">
          <div class="p-4 border rounded shadow-sm h-100">
            <i class="bi bi-headset fs-1 text-warning mb-3"></i>
            <h5>Поддержка 24/7</h5>
            <p>Круглосуточная поддержка клиентов</p>
          </div>
        </div>
        <div class="col-md-3 mb-4">
          <div class="p-4 border rounded shadow-sm h-100">
            <i class="bi bi-arrow-repeat fs-1 text-warning mb-3"></i>
            <h5>Легкий возврат</h5>
            <p>Возврат товара в течение 30 дней</p>
          </div>
        </div>
      </div>

<div class="container mb-5">
    <h2 class="text-center mb-4">Наши топовые товары</h2>
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-6 col-sm-8">
            <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#productCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <div class="card border-0 shadow" style="height: 500px;">
                            <div class="d-flex flex-column h-100">
                                <div class="flex-grow-1" style="height: 280px; overflow: hidden;">
                                    <img src="assets/image/ek68.png"
                                         class="card-img-top w-100 h-100"
                                         alt="Игровая клавиатура"
                                         style="object-fit: cover;">
                                </div>
                                <div class="card-body text-center p-3 d-flex flex-column">
                                    <h5 class="card-title mb-2">Механические игровые клавиатуры</h5>
                                    <p class="card-text flex-grow-1">Максимальная отзывчивость и тактильная отдача для победы в любых играх</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <div class="card border-0 shadow" style="height: 500px;">
                            <div class="d-flex flex-column h-100">
                                <div class="flex-grow-1" style="height: 280px; overflow: hidden;">
                                    <img src="assets\image\sorav2.png"
                                         class="card-img-top w-100 h-100"
                                         alt="Игровая мышь"
                                         style="object-fit: cover;">
                                </div>
                                <div class="card-body text-center p-3 d-flex flex-column">
                                    <h5 class="card-title mb-2">Высокоточные игровые мыши</h5>
                                    <p class="card-text flex-grow-1">Идеальный контроль и настраиваемые кнопки для профессиональных геймеров</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <div class="card border-0 shadow" style="height: 500px;">
                            <div class="d-flex flex-column h-100">
                                <div class="flex-grow-1" style="height: 280px; overflow: hidden;">
                                    <img src="assets/image/moondrop.png"
                                         class="card-img-top w-100 h-100"
                                         alt="Игровые наушники"
                                         style="object-fit: cover;">
                                </div>
                                <div class="card-body text-center p-3 d-flex flex-column">
                                    <h5 class="card-title mb-2">Игровые гарнитуры</h5>
                                    <p class="card-text flex-grow-1">Погрузитесь в игру с объемным звуком и четким голосовым чатом</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </div>
</div>

@endsection
