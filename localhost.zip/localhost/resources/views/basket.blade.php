@extends('layouts.app')

@section('content')
    <div class="o_nas">
        <h1>Корзина</h1>
    </div>
    <div class="d-flex justify-content-center">
        <div class="card mb-3 m-5" style="width: 70em;">
            <div class="row g-0">
                <div class="col-md-4">
                    <img src="public/assets/img/image.png" class="img-fluid rounded-start" alt="...">
                </div>
                <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title fs-1">Принтер</h5>
                        <p class="card-text fs-3">Крутой принтер</p>
                        <p class="card-text fs-4">2т.</p>
                    </div>
                </div>
            </div>
            <div class="card" style="height: 20px width: 30rem;">
                <div class="card-body">
                    <p class="card-text">Товар: 1</p>
                    <p class="card-text">Скидка: 0.т</p>
                    <p class="card-text">Адресс: Буммашевская ул., 17А, Ижевск</p>
                    <p class="card-text">2т.</p>
                    <a href="{{ route('order') }}" class="btn btn-primary">Купить</a>
                    <div class="main">
                        <a href="{{ route('catalog') }}">Продолжить покупки</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
