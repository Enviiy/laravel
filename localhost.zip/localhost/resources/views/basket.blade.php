@extends('layouts.app')

@section('content')
    <div class="container py-4 pt-5 mt-5">
        <div class="row">
            <div class="col-md-6">
                <h1 class="mb-3">Корзина</h1>
            </div>
        </div>
        <div class="border-bottom border-2 border-secondary mb-4"></div>
        <div class="row g-4">
            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="row g-0 align-items-center">
                        <div class="col-md-2">
                            <img src="/assets/image/sorav2.png" class="img-fluid rounded-start" alt="Ninjutso Sora V2" style="max-height: 150px; object-fit: contain;">
                        </div>
                        <div class="col-md-10">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-lg-5">
                                        <h5 class="card-title fw-bold mb-2">Ninjutso Sora V2</h5>
                                        <p class="card-text text-muted small mb-2">Сверхлегкая (39-40 г) беспроводная игровая мышь симметричной формы</p>
                                        <span class="text-success small"><i class="bi bi-check-circle-fill me-1"></i>В наличии</span>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="d-flex align-items-center">
                                            <button class="btn btn-outline-secondary btn-sm" type="button">−</button>
                                            <span class="mx-3 fw-bold">1</span>
                                            <button class="btn btn-outline-secondary btn-sm" type="button">+</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <span class="h5 fw-bold mb-0">6 999 ₽</span>
                                    </div>
                                    <div class="col-lg-2 text-end">
                                        <button class="btn btn-outline-danger btn-sm">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="row g-0 align-items-center">
                        <div class="col-md-2">
                            <img src="/assets/image/ek68.png" class="img-fluid rounded-start" alt="Epomaker EK68" style="max-height: 150px; object-fit: contain;">
                        </div>
                        <div class="col-md-10">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-lg-5">
                                        <h5 class="card-title fw-bold mb-2">Epomaker EK68</h5>
                                        <p class="card-text text-muted small mb-2">Компактная (65%, 68 клавиш) механическая клавиатура с тремя режимами подключения</p>
                                        <span class="text-success small"><i class="bi bi-check-circle-fill me-1"></i>В наличии</span>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="d-flex align-items-center">
                                            <button class="btn btn-outline-secondary btn-sm" type="button">−</button>
                                            <span class="mx-3 fw-bold">1</span>
                                            <button class="btn btn-outline-secondary btn-sm" type="button">+</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <div>
                                            <span class="h5 fw-bold mb-0 text-primary">3,999 ₽</span>
                                            <small class="text-muted text-decoration-line-through d-block">5,999 ₽</small>
                                        </div>
                                    </div>
                                    <div class="col-lg-2 text-end">
                                        <button class="btn btn-outline-danger btn-sm">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="row mt-2">
                                    <div class="col-12">
                                        <span class="badge bg-warning bg-opacity-10 text-warning">Скидка 15%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12">
                <div class="card shadow-sm border-0">
                    <div class="row g-0 align-items-center">
                        <div class="col-md-2">
                            <img src="/assets/image/moondrop.png" class="img-fluid rounded-start" alt="Moondrop Blessing 3" style="max-height: 150px; object-fit: contain;">
                        </div>
                        <div class="col-md-10">
                            <div class="card-body">
                                <div class="row align-items-center">
                                    <div class="col-lg-5">
                                        <h5 class="card-title fw-bold mb-2">Moondrop Blessing 3</h5>
                                        <p class="card-text text-muted small mb-2">Гибридные наушники премиум-класса (2DD+4BA) для истинных ценителей звука</p>
                                        <span class="text-success small"><i class="bi bi-check-circle-fill me-1"></i>В наличии</span>
                                    </div>
                                    <div class="col-lg-3">
                                        <div class="d-flex align-items-center">
                                            <button class="btn btn-outline-secondary btn-sm" type="button">−</button>
                                            <span class="mx-3 fw-bold">1</span>
                                            <button class="btn btn-outline-secondary btn-sm" type="button">+</button>
                                        </div>
                                    </div>
                                    <div class="col-lg-2">
                                        <span class="h5 fw-bold mb-0">32 000 ₽</span>
                                    </div>
                                    <div class="col-lg-2 text-end">
                                        <button class="btn btn-outline-danger btn-sm">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row-4">
            <div class="col ms-auto">
                <div class="card shadow-sm border-0 bg-light">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-4">Итого в корзине</h5>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Товары (3 шт.)</span>
                            <span class="fw-bold">44 999 ₽</span>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Скидка</span>
                            <span class="text-danger fw-bold">−2 000 ₽</span>
                        </div>
                        <div class="d-flex justify-content-between mb-3">
                            <span class="text-muted">Доставка</span>
                            <span class="text-success fw-bold">Бесплатно</span>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="h5 fw-bold">К оплате:</span>
                            <span class="h4 fw-bold text-primary">44 999 ₽</span>
                        </div>
                        <div class="d-grid gap-2">
                            <a href="" class="btn btn-primary btn-lg">Оформить заказ</a>
                            <a href="{{ route('catalog') }}" class="btn btn-outline-secondary">Продолжить покупки</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
