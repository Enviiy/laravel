@extends('layouts.app')

@section('content')

<h1 class="m-5">Продукт:</h1>
<div class="card mb-3 m-5" style="w-10">
    <div class="row g-0">
        <div class="col-md-4">
            <img src="../public/{{$card->image}}" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title fs-1">{{$card->name_product}}</h5>
                <p class="card-text fs-3">{{$card->description_product}}</p>
                <p class="card-text fs-4">{{$card->year_product}}</p>
                <p class="card-text fs-4">{{$card->country_product}}</p>
                <p class="card-text fs-4">{{$card->model_product}}</p>
                <p class="card-text fs-4">{{$card->price_product}} рублей</p>
                <a href="{{ route('basket', parameters: $card->id_product) }}" class="btn btn-primary fs-5">В корзину</a>
            </div>
        </div>
    </div>
</div>

@endsection
