@extends('layouts.app')

@section('content')
    @foreach($array as $a)
<h1 class="m-5">Продукт:</h1>
<div class="card mb-3 m-5" style="w-10">
    <div class="row g-0">
        <div class="col-md-4">
            <img src="../public/{{$a ->image}}" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title fs-1">{{$a ->name_product}} </h5>
                <p class="card-text fs-3">{{$a ->description_product}} </p>
                <p class="card-text fs-4">Год выпуска: {{$a ->year_product}}</p>
                <p class="card-text fs-4">Страна: {{$a ->country_product}}</p>
                <p class="card-text fs-4">Модель: {{$a ->model_product}}</p>
                <p class="card-text fs-4">Цена: {{$a ->price_product}} рублей</p>
                <a href="{{ route('basket') }}" class="btn btn-primary fs-5">В корзину</a>
            </div>
        </div>
    </div>
</div>
    @endforeach
@endsection
