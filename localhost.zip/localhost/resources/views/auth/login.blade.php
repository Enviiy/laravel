@extends('layouts.app')

@section('content')
<div class="container pt-5 mt-5 align-items-center">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5 col-xl-4">
        <div class="text-center mb-4">
          <h2 class="fw-bold mt-3">Войдите в свой аккаунт</h2>
        </div>

        <div class="card border-0 shadow-lg">
          <div class="card-body p-4">
            <form>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-envelope text-primary"></i>
                  </span>
                  <input
                    type="email"
                    class="form-control border-0 bg-light"
                    placeholder="Email"
                    value="user@example.com"
                  />
                </div>
              </div>

              <div class="mb-4">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-lock text-primary"></i>
                  </span>
                  <input
                    type="password"
                    class="form-control border-0 bg-light"
                    placeholder="Пароль"
                    value="12345678"
                  />
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-eye-slash text-muted"></i>
                  </span>
                </div>
              </div>

              <div class="d-flex justify-content-between mb-4">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="remember" checked>
                  <label class="form-check-label small" for="remember">
                    Запомнить
                  </label>
                </div>
                <a href="#" class="small text-decoration-none text-primary">
                  Забыли пароль?
                </a>
              </div>

              <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">
                Войти
              </button>
            </form>

            <hr class="my-4">

            <div class="text-center">
              <p class="small text-muted mb-3">Нет аккаунта?</p>
              <a href="reg.html" class="btn btn-outline-primary w-100 py-2">
                Создать аккаунт
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
@endsection
