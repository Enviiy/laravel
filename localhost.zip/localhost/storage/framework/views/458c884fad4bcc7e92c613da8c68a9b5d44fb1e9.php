<?php $__env->startSection('content'); ?>
<h1 class="m-5">Продукт:</h1>
<div class="card mb-3 m-5" style="w-10">
    <div class="row g-0">
        <div class="col-md-4">
            <img src="public/assets/img/image.png" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title fs-1">Принтер</h5>
                <input class="form-control" type="text" value="Изменить название" aria-label="readonly input example" readonly><br>
                <p class="card-text fs-3">Очень крутой и качественный принтер, прям вообще топ за свои деньги</p>
                <input class="form-control" type="text" value="Изменить описание" aria-label="readonly input example" readonly><br>
                <p class="card-text fs-4">Год выпуска: 1996</p>
                <input class="form-control" type="text" value="Изменить год выпуска" aria-label="readonly input example" readonly><br>
                <p class="card-text fs-4">Страна: Россия</p>
                <input class="form-control" type="text" value="Изменить страну" aria-label="readonly input example" readonly><br>
                <p class="card-text fs-4">Модель: ULTRA MAX TERMINATOR PRO EDITION SUPER</p>
                <input class="form-control" type="text" value="Изменить модель" aria-label="readonly input example" readonly><br>
                <p class="card-text fs-4">2к рублей</p>
                <input class="form-control" type="text" value="Изменить цену" aria-label="readonly input example" readonly><br>
                <a href="<?php echo e(route('catalog')); ?>" class="btn btn-primary">Применить</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel2\domains\localhost\resources\views/redact_product.blade.php ENDPATH**/ ?>