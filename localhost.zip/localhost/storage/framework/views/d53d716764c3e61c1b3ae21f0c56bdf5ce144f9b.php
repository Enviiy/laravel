<?php $__env->startSection('content'); ?>
  <div class="container py-4">
    <div class="row mb-4">
      <div class="col-md-6">
        <h1 class="mb-3">Каталог игровой периферии</h1>
        <p class="text-muted">Выберите лучшие устройства для вашего игрового опыта</p>
      </div>
      <div class="col-md-6">
        <div class="input-group mb-3">
          <input type="text" class="form-control" placeholder="Поиск товаров...">
          <button class="btn btn-primary" type="button">Найти</button>
        </div>
      </div>
    </div>

    <div class="row mb-4">
      <div class="col-12">
        <div class="btn-group" role="group">
          <button type="button" class="btn btn-outline-primary active">Все товары</button>
          <button type="button" class="btn btn-outline-primary">Клавиатуры</button>
          <button type="button" class="btn btn-outline-primary">Мыши</button>
          <button type="button" class="btn btn-outline-primary">Наушники</button>
          <button type="button" class="btn btn-outline-primary">Микрофоны</button>
          <button type="button" class="btn btn-outline-primary">Коврики</button>
          <button type="button" class="btn btn-outline-primary">Мониторы</button>
        </div>
      </div>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <div class="position-relative">
            <img src="/assets/image/sorav2.png" class="card-img-top" alt="Mouse">
          </div>
          <div class="card-body ">
            <h5 class="card-title">Ninjutso Sora V2</h5>
            <p class="card-text">Ninjutso Sora V2 — это
                сверхлегкая (39-40 г) беспроводная игровая мышь симметричной формы, разработанная для когтевого хвата.
            </p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0">6, 999 ₽</span>
              <span class="text-success"><i class="bi bi-check-circle"></i> В наличии</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <div class="position-relative">
            <img src="/assets/image/ek68.png" class="card-img-top" alt="keyboard">
            <span class="badge bg-warning position-absolute top-0 end-0 m-2">Скидка 15%</span>
          </div>
          <div class="card-body">
            <h5 class="card-title">Epomaker EK68</h5>
            <p class="card-text">компактная (65%, 68 клавиш) механическая клавиатура с тремя режимами подключения (USB-C, 2.4 ГГц, Bluetooth)</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0"><s class="text-muted">5,999 ₽</s> 3,999 ₽</span>
              <span class="text-success"><i class="bi bi-check-circle"></i> В наличии</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <img src="/assets/image/moondrop.png" class="card-img-top" alt="headphones">
          <div class="card-body">
            <h5 class="card-title">Moondrop Blessing 3</h5>
            <p class="card-text">Moondrop Blessing 3 — это внутриканальные гибридные наушники (2DD+4BA) премиум-класса</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0">32,000 ₽</span>
              <span class="text-success"><i class="bi bi-check-circle"></i> В наличии</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <img src="/assets/image/AM8.png" class="card-img-top" alt="Microphone">
          <div class="card-body">
            <h5 class="card-title">Fifine AmpliGame AM8</h5>
            <p class="card-text">Fifine AmpliGame AM8 - это динамический микрофон с проводным подключением, который отлично подойдет для записи подкастов, стримов, озвучки, проведения трансляций на ютубе.</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0">4,499 ₽</span>
              <span class="text-warning"><i class="bi bi-clock"></i> Осталось 3 шт.</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <img src="/assets/image/cgmp.png" class="card-img-top" alt="Mouse pad">
          <div class="card-body">
            <h5 class="card-title">ControlGamingGear</h5>
            <p class="card-text">Игровой коврик увеличенного размера с прошитыми краями и оптимальным контролем.</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0">2,499 ₽</span>
              <span class="text-success"><i class="bi bi-check-circle"></i> В наличии</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card h-100 shadow-sm border-0">
          <div class="position-relative">
            <img src="/assets/image/xiaomi.png" class="card-img-top" alt="Monitor">
            <span class="badge bg-info position-absolute top-0 end-0 m-2">Новинка</span>
          </div>
          <div class="card-body">
            <h5 class="card-title"> Xiaomi Fast LCD Monitor 24.5</h5>
            <p class="card-text">Монитор Xiaomi Mi Display Fast LCD Desktop Monitor с практически незаметной рамкой обеспечивает качественное изображение и комфорт просмотра.</p>
            <div class="d-flex justify-content-between align-items-center">
              <span class="h5 mb-0">19,999 ₽</span>
              <span class="text-success"><i class="bi bi-check-circle"></i> В наличии</span>
            </div>
          </div>
          <div class="card-footer bg-white border-0">
            <div class="d-grid">
              <a href="cart.html" class="btn btn-primary">В корзину</a>
            </div>
          </div>
        </div>
      </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/catalog.blade.php ENDPATH**/ ?>