<?php $__env->startSection('content'); ?>
<h1 class="m-5">Продукт:</h1>
<div class="card mb-3 m-5" style="w-10">
    <div class="row g-0">
        <div class="col-md-4">
            <img src="public/assets/img/image.png" class="img-fluid rounded-start" alt="...">
        </div>
        <div class="col-md-8">
            <div class="card-body">
                <h5 class="card-title fs-1">Принтер</h5>
                <p class="card-text fs-3">Очень крутой и качественный принтер, прям вообще топ за свои деньги</p>
                <p class="card-text fs-4">Год выпуска: 1996</p>
                <p class="card-text fs-4">Страна: Россия</p>
                <p class="card-text fs-4">Модель: ULTRA MAX TERMINATOR PRO EDITION SUPER</p>
                <p class="card-text fs-4">2к рублей</p>
                <a href="<?php echo e(route('basket')); ?>" class="btn btn-primary fs-5">В корзину</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel2\domains\localhost\resources\views/product.blade.php ENDPATH**/ ?>