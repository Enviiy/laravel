<?php $__env->startSection('content'); ?>
    <div class="o_nas">
        <h1>Заказ успешно оформлен!</h1>
        <a href="<?php echo e(url('/')); ?>" class="btn btn-primary fs-3" style="display: block; justify-self: center; margin-top: 30px;">на главную</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel2\domains\localhost\resources\views/complite.blade.php ENDPATH**/ ?>