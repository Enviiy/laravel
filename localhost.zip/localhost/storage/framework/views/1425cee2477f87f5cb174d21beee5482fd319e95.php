<?php $__env->startSection('content'); ?>
<div class="container d-grid" style="max-width: 700px; width: 100%; margin-top: 100px;">
    <select class="form-select" aria-label="Default select example">
        <option selected>Сортировать по</option>
        <option value="1">Году выпуска</option>
        <option value="2">Названию</option>
        <option value="3">цене</option>
        <option value="4">лазерные принтеры</option>
        <option value="5">струйные принтеры</option>
        <option value="6">термопринтеры</option>
    </select>
</div>
<div class="container d-grid">
    <div class="row mb-3 gap-3 ">
<?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <form style="width: auto" action="<?php echo e(route ('product', ['id'=>$a->id_product])); ?>">
            <div class="card" style="width: 24rem; padding: 15px; margin-top: 50px;">
                <img src="public/<?php echo e($a->image); ?>" class="card-img-top" alt="">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($a->name_product); ?> </h5>
                    <p class="card-text"><?php echo e($a->description_product); ?></p>
                    <p class="card-text"><?php echo e($a->price_product); ?> рублей</p>
                    <button type="submit" class="btn btn-primary fs-6">Подробнее</button>
                    <a href="<?php echo e(route('basket',  $a->id_product)); ?>" class="btn btn-primary fs-6">В корзину</a>
                    <a href="<?php echo e(route('redact_product')); ?>" class="btn btn-primary fs-6">Изменить</a>
                </div>
            </div>
            </form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel2\domains\localhost\resources\views/catalog.blade.php ENDPATH**/ ?>