<?php $__env->startSection('content'); ?>
  <div class="container pt-5 mt-5 align-items-center">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5 col-xl-4">
        <div class="text-center mb-4">
          <h2 class="fw-bold mt-3">Регистрация</h2>
        </div>

        <div class="card border-0 shadow-lg">
          <div class="card-body p-4">
            <form>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-person text-primary"></i>
                  </span>
                  <input
                    type="text"
                    class="form-control border-0 bg-light"
                    placeholder="Имя"
                    value=""
                  />
                </div>
              </div>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-person text-primary"></i>
                  </span>
                  <input
                    type="text"
                    class="form-control border-0 bg-light"
                    placeholder="Фамилия"
                    value=""
                  />
                </div>
              </div>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-envelope text-primary"></i>
                  </span>
                  <input
                    type="email"
                    class="form-control border-0 bg-light"
                    placeholder="Email"
                    value=""
                  />
                </div>
              </div>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-phone text-primary"></i>
                  </span>
                  <input
                    type="text"
                    class="form-control border-0 bg-light"
                    placeholder="Телефон"
                    value=""
                  />
                </div>
              </div>
              <div class="mb-3">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-calendar text-primary"></i>
                  </span>
                  <input
                    type="date"
                    class="form-control border-0 bg-light"
                    placeholder="Дата рождения"
                    value=""
                  />
                </div>
              </div>

              <div class="mb-4">
                <div class="input-group">
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-lock text-primary"></i>
                  </span>
                  <input
                    type="password"
                    class="form-control border-0 bg-light"
                    placeholder="Пароль"
                    value=""
                  />
                  <span class="input-group-text bg-light border-0">
                    <i class="bi bi-eye-slash text-muted"></i>
                  </span>
                </div>
              </div>

              <div class="d-flex justify-content-between mb-4">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="remember" checked>
                  <label class="form-check-label small" for="remember">
                    Запомнить
                  </label>
                </div>
              </div>

              <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">
                Зарегестрироваться
              </button>
            </form>

            <hr class="my-4">

            <div class="text-center">
              <p class="small text-muted mb-3">Уже есть аккаунт?</p>
              <a href="reg.html" class="btn btn-outline-primary w-100 py-2">
                Войти
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/auth/register.blade.php ENDPATH**/ ?>