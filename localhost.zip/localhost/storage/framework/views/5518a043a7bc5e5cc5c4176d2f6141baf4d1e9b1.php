<?php $__env->startSection('content'); ?>
    <div class="conteiner">
        <div class="row" style="display: block; justify-self: center;">
            <h1 class="m-5">Добавить товар</h1>
            <div class="card p-2 m-5" style="width: 18rem;">
                <div class="mb-3">
                    <label for="formFile" class="form-label">Добавить фото</label>
                    <input class="form-control" type="file" id="formFile">
                </div>
                <div class="card-body">
                    <input class="form-control" type="text" value="Название товара" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Описание" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Цена" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Год выпуска" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Модель" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Страна" aria-label="readonly input example" readonly><br>
                    <a href="#" class="btn btn-primary">Добавить</a>
                </div>
            </div>
            <h1 class="m-5">Добавить категорию</h1>
            <div class="card p-2 m-5" style="width: 18rem;">
                <div class="card-body">
                    <input class="form-control" type="text" value="Название категории" aria-label="readonly input example" readonly><br>
                    <input class="form-control" type="text" value="Описание" aria-label="readonly input example" readonly><br>
                    <select class="form-select form-select-sm" aria-label="Small select example">
                        <option selected>выберите товар</option>
                        <option value="1">принтер</option>
                        <option value="2">принтер</option>
                        <option value="3">принтер</option>
                    </select><br>
                    <a href="#" class="btn btn-primary">Добавить</a>
                </div>
            </div>

            <h1 class="m-5">удалить категорию</h1>
            <div class="card p-2 m-5" style="width: 18rem;">
                <div class="card-body">
                    <select class="form-select form-select-sm" aria-label="Small select example">
                        <option selected>выберите категорию</option>
                        <option value="1">Категория 1</option>
                        <option value="2">Категория 2</option>
                        <option value="3">Категория 3</option>
                    </select>
                    <a href="#" class="btn btn-danger" style="margin-top: 10px;">Удалить</a>
                </div>
            </div>

            <h1 class="m-5">Заказы</h1>
            <div class="container d-grid" style="max-width: 1150px; width: 100%;">
                <select class="form-select" aria-label="Default select example">
                    <option selected>Фильтр</option>
                    <option value="1">Новые</option>
                    <option value="2">Подтвержденные</option>
                    <option value="3">Отмененные</option>
                </select>
            </div>
            <div class="container d-grid">
                <div class="row m-5 gap-3 ">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">ФИО</th>
                            <th scope="col">название</th>
                            <th scope="col">Статус</th>
                            <th scope="col">кол-во</th>
                            <th scope="col">Время</th>
                            <th scope="col"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Пономорев Максим Денисович</td>
                            <td>принтер</td>
                            <td>Подтвержденный</td>
                            <td>1 шт.</td>
                            <td>18:32:00</td>
                            <td><a href="#" class="card-link">Принять</a> <a href="#" class="card-link">Отменить</a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Пономорев Максим Денисович</td>
                            <td>принтер</td>
                            <td>Подтвержденный</td>
                            <td>1 шт.</td>
                            <td>18:32:00</td>
                            <td><a href="#" class="card-link">Принять</a> <a href="#" class="card-link">Отменить</a></td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Пономорев Максим Денисович</td>
                            <td>принтер</td>
                            <td>Подтвержденный</td>
                            <td>1 шт.</td>
                            <td>18:32:00</td>
                            <td><a href="#" class="card-link">Принять</a> <a href="#" class="card-link">Отменить</a></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel2\domains\localhost\resources\views/admp.blade.php ENDPATH**/ ?>