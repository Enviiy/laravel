<?php $__env->startSection('content'); ?>
    <div class="o_nas">
        <h1>где нас найти</h1>
    </div>
    <div class="card" style="width: 50rem; padding: 20px; margin-top: 100px;">
        <div style="position:relative;overflow:hidden;"><a href="https://yandex.ru/maps/org/lyudmila/1070684687/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:0px;">Людмила</a><a href="https://yandex.ru/maps/44/izhevsk/category/cafe/184106390/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:14px;">Кафе в Ижевске</a><a href="https://yandex.ru/maps/44/izhevsk/category/banquet_hall/184108315/?utm_medium=mapframe&utm_source=maps" style="color:#eee;font-size:12px;position:absolute;top:28px;">Банкетный зал в Ижевске</a><iframe src="https://yandex.ru/map-widget/v1/?ll=53.236355%2C56.879324&mode=search&oid=1070684687&ol=biz&z=17.08" width="800" height="400" frameborder="1" allowfullscreen="true" style="position:relative;"></iframe></div>
        <div class="card-body">
            <h5 class="card-title">Буммашевская ул., 17А, Ижевск</h5>
            <h5 class="card-title">printer@gmail.com</h5>
            <h5 class="card-title">+7 (982) 777 - 77 - 77</h5>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH W:\domains\localhost\resources\views/poisk.blade.php ENDPATH**/ ?>